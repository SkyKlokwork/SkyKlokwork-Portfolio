class checkBook {

private:
float balance;
float lastCheck;
float lastDeposit;

public:
void setBalance (float amount);
bool writeCheck(float amount);
 //returns false if not enough money, true otherwise
void deposit(float amount);
float getBalance();
float getLastCheck();
float getLastDeposit();
//checkBook();
//~checkBook();
};