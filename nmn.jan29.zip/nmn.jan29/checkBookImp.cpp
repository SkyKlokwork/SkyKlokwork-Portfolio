#include "checkBook.h"
#include <iostream>
#include <iomanip>

using namespace std;


void checkBook::setBalance(float amount)
   {
   balance = amount;
   }
   
bool checkBook::writeCheck(float amount)
   {
      if (amount > balance)
            return false;
      balance -= amount;
      lastCheck = amount;
      return true;
    }

void checkBook::deposit(float amount)
   {
      balance += amount;
      lastDeposit = amount;
   }
   
float checkBook::getBalance()
   {
      return balance;
   }

float checkBook::getLastCheck()
   {
      return lastCheck;
   }

float checkBook::getLastDeposit()
   {
      return lastDeposit;
   }
